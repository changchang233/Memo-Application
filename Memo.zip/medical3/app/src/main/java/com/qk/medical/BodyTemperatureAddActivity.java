package com.qk.medical;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;

import com.blankj.utilcode.util.TimeUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.qk.medical.database.operation.MySQLiteOpenHelper;
import com.qk.medical.database.tableInfor.BodyTemperature;
import com.qk.medical.gen.BodyTemperatureDao;
import com.qk.medical.util.QKTextUtils;

import java.util.Calendar;

import butterknife.BindView;

/**
 * @ClassName: BodyTemperatureAddActivity
 * @Description: Body Temperature Add page
 * @Author:
 * @Version: 1.6.0
 */
public class BodyTemperatureAddActivity extends BaseActivity {

    @BindView(R.id.et_pulse)
    EditText etPulse;
    @BindView(R.id.et_pulse_note)
    EditText etPulseNote;
    @BindView(R.id.date_picker)
    DatePicker datePicker;
    String time;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_add_body_temperature;
    }

    @Override
    protected void initToolbar(Bundle savedInstanceState) {
        setTitle("Body Temperature Add Page");
        showRight(true);
        setRightText("Save");
        //when click save
        setOnRightClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tem = etPulse.getText().toString().trim();
                String note = etPulseNote.getText().toString().trim();
                if(QKTextUtils.isNullOrEmpty(tem)){
                    ToastUtils.showShort("Please input BodyTemperature");
                    return;
                }
                BodyTemperatureDao dao = MySQLiteOpenHelper.getDaoSession(mContext).getBodyTemperatureDao();
                BodyTemperature bodyTemperature = new BodyTemperature();
                bodyTemperature.setBodyTemp(tem);
                bodyTemperature.setDate(time);
                bodyTemperature.setNotes(note);
                Long resultId = dao.insert(bodyTemperature);
                Intent resultIntent = new Intent();
                resultIntent.putExtra("temp", tem);
                resultIntent.putExtra("time", time);
                resultIntent.putExtra("note", note);
                resultIntent.putExtra("id", resultId);
                setResult(RESULT_OK, resultIntent);
                finish();
            }
        });
    }

    /**
     * when select date
     */
    @Override
    protected void initData() {
        time = TimeUtils.date2String(TimeUtils.getNowDate(), "yyyy/MM/dd");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            datePicker.setOnDateChangedListener(new DatePicker.OnDateChangedListener() {
                //when click calendar
                @Override
                public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                    Log.e("KK", "year=" + year + ",month=" + monthOfYear + ",day=" + dayOfMonth);
                    time = new StringBuffer().append(year).append("Year")
                            .append((monthOfYear + 1)).append("Month")
                            .append(dayOfMonth).append("Day").toString();
                }
            });
        }
    }

}
