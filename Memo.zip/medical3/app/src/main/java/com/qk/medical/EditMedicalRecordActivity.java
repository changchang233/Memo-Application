package com.qk.medical;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.Nullable;

import com.blankj.utilcode.util.ToastUtils;
import com.qk.medical.database.operation.MySQLiteOpenHelper;
import com.qk.medical.database.tableInfor.MedicalHistory;
import com.qk.medical.gen.MedicalHistoryDao;
import com.qk.medical.util.QKTextUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import butterknife.BindView;

/**
 * @ClassName: EditMedicalRecordActivity
 * @Description: set the medical reocord add
 * @Author:
 * @Version: 1.6.0
 */
public class EditMedicalRecordActivity extends BaseActivity {
    Long id;
    @BindView(R.id.et_condition_one)
    EditText etConditionOne;
    @BindView(R.id.et_condition_two)
    EditText etConditionTwo;
    @BindView(R.id.et_medication)
    EditText etMedication;
    @BindView(R.id.et_medication_two)
    EditText etMedicationTwo;
    @BindView(R.id.et_date_one)
    EditText etDateOne;
    @BindView(R.id.et_date_two)
    EditText etDateTwo;
    @BindView(R.id.et_note)
    EditText etNote;
    private MedicalHistoryDao dao;
    private int pos = -1;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_edit_medical_record;
    }

    @Override
    protected void initToolbar(Bundle savedInstanceState) {
        setTitle("Medical Health Record Add Page");
        showRight(true);
        setRightText("Save");
        setOnRightClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveData();
            }
        });
    }

    @Override
    protected void initData() {
        dao = MySQLiteOpenHelper.getDaoSession(mContext).getMedicalHistoryDao();
        id = getIntent().getLongExtra("id", 0L);
        pos = getIntent().getIntExtra("pos", -1);
        MedicalHistory history = dao.queryBuilder().where(MedicalHistoryDao.Properties.Id.eq(id)).unique();
        if(history != null){
            bindData(history);
        }
        //select condition 1
        etConditionOne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, ConditionActivity.class);
                intent.putExtra("pos", 0);
                startActivityForResult(intent, 101);
            }
        });

        //select condition 2
        etConditionTwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, ConditionActivity.class);
                intent.putExtra("pos", 1);
                startActivityForResult(intent, 102);
            }
        });
    }

    /**
     * The submodule returns some data to the main Activity for processing
     * @param requestCode confirm the data is returned from which activity
     * @param resultCode RESULT OK > call back
     *                   RESULT CANCELLED > no call back
     * @param data data that passes
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 101 && resultCode == RESULT_OK && data != null){
            String content = data.getStringExtra("data");
            etConditionOne.setText(content);
        }else if(requestCode == 102 && resultCode == RESULT_OK && data != null){
            String content = data.getStringExtra("data");
            etConditionTwo.setText(content);
        }
    }

    /**
     * get user input and check if it is legal
     *
     */
    private void saveData() {

        //must select a condition
        String conditionOne = etConditionOne.getText().toString().trim();
        String conditionTwo = etConditionTwo.getText().toString().trim();
        if(QKTextUtils.isNullOrEmpty(conditionOne) || conditionOne.replace(" ", "").equals("---")){
            ToastUtils.showShort("Please select condition");
            return;
        }

        //must input medication 1
        String medication = etMedication.getText().toString().trim();
        String medicationTwo = etMedicationTwo.getText().toString().trim();
        if(QKTextUtils.isNullOrEmpty(medication)){
            ToastUtils.showShort("Please input medication");
            return;
        }

        //must input start date and end date
        String date = etDateOne.getText().toString().trim();
        String dateTwo = etDateTwo.getText().toString().trim();
        if(QKTextUtils.isNullOrEmpty(date)){
            ToastUtils.showShort("Please input start date");
            return;
        }
        SimpleDateFormat sd=new SimpleDateFormat("yyyy-MM-dd");
        try {
            sd.setLenient(false);
            sd.parse(date);
        }
        catch (Exception e) {
            ToastUtils.showShort("please input correct start date");
            return;
        }

        try {
            sd.setLenient(false);
            sd.parse(dateTwo);
        }
        catch (Exception e) {
            ToastUtils.showShort("please input correct end date");
            return;
        }

        //end date should after start date
        try {
            sd.setLenient(false);
            Date dateA = sd.parse(date);
            Date dateB = sd.parse(dateTwo);
            int compare = dateA.compareTo(dateB);
            if(compare>0){
                ToastUtils.showShort("end date should after start date");
                return;
            }
        }catch (Exception e){
        }


        String note = etNote.getText().toString().trim();
        MedicalHistory history = new MedicalHistory();
        //set data into obj to store
        if(id != 0){
            history.setId(id);
        }
        history.setSymptom(conditionOne);
        history.setSymptom_two(conditionTwo);
        history.setMedications(medication);
        history.setMedications_two(medicationTwo);
        history.setDateOftaking(date);
        history.setDateOfstop(dateTwo);
        history.setNotes(note);
        Long resultId = dao.insertOrReplace(history);
        Intent intent = new Intent();
        if(pos >= 0){
            intent.putExtra("pos", pos);
        }
        intent.putExtra("conditionOne", conditionOne);
        intent.putExtra("conditionTwo", conditionTwo);
        intent.putExtra("medication", medication);
        intent.putExtra("medicationTwo", medicationTwo);
        intent.putExtra("date", date);
        intent.putExtra("dateTwo", dateTwo);
        intent.putExtra("note", note);
        intent.putExtra("id", resultId);
        setResult(RESULT_OK, intent);
        ToastUtils.showShort("save!");
        finish();
    }


    /**
     * show the previous data according to the history
     * @param history the history that need to show symptom and mediation
     */
    private void bindData(MedicalHistory history){
        etConditionOne.setText(history.getSymptom());
        if(!QKTextUtils.isNullOrEmpty(history.getSymptom_two())){
            etConditionTwo.setText(history.getSymptom_two());
        }
        etMedication.setText(history.getMedications());
        if(!QKTextUtils.isNullOrEmpty(history.getMedications_two())){
            etMedicationTwo.setText(history.getMedications_two());
        }
        etDateOne.setText(history.getDateOftaking());
        if(!QKTextUtils.isNullOrEmpty(history.getDateOfstop())){
            etDateTwo.setText(history.getDateOfstop());
        }
        if(!QKTextUtils.isNullOrEmpty(history.getNotes())){
            etNote.setText(history.getNotes());
        }
    }
}
