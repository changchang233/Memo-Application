/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.qk.medical.database.tableInfor;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Generated;
import org.greenrobot.greendao.annotation.Id;

/**
 *
 * @author xuxiaoyue
 */
@Entity
public class Pulse {
    @Id
    private Long id;

    private String pulse;
    private String date;
    private String notes;
    @Generated(hash = 882921871)
    public Pulse(Long id, String pulse, String date, String notes) {
        this.id = id;
        this.pulse = pulse;
        this.date = date;
        this.notes = notes;
    }
    @Generated(hash = 1184536889)
    public Pulse() {
    }
    public Long getId() {
        return this.id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getPulse() {
        return this.pulse;
    }
    public void setPulse(String pulse) {
        this.pulse = pulse;
    }
    public String getDate() {
        return this.date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public String getNotes() {
        return this.notes;
    }
    public void setNotes(String notes) {
        this.notes = notes;
    }
}
