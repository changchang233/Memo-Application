package com.qk.medical;


import android.os.Bundle;
import android.widget.TextView;

import butterknife.BindView;

public class HelpActivity extends BaseActivity {
    @BindView(R.id.introTitle)
    TextView introTitle;
    @BindView(R.id.intro)
    TextView intro;
    @BindView(R.id.functionTitle)
    TextView functionTitle;
    @BindView(R.id.function)
    TextView function;

    @BindView(R.id.email)
    TextView email;
    protected int getLayoutId() {
        return R.layout.activity_help;
    }

    @Override
    protected void initToolbar(Bundle savedInstanceState) {
        setTitle("Help");
    }

    @Override
    protected void initData() {

    }
}
