package com.qk.medical;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;

import com.blankj.utilcode.util.TimeUtils;
import com.qk.medical.database.operation.MySQLiteOpenHelper;
import com.qk.medical.database.tableInfor.AlarmClock;
import com.qk.medical.gen.AlarmClockDao;
import com.qk.medical.util.AlarmReceiver;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * @ClassName: ReminderActivity
 * @Description: Remind function
 * @Author:
 * @Version: 1.6.0
 */
public class ReminderActivity extends BaseActivity {
    @BindView(R.id.iv_delete_clock)
    ImageView ivDeleteClock;
    @BindView(R.id.tv_clock)
    TextView tvClock;
    @BindView(R.id.iv_add_clock)
    ImageView ivAddClock;
    @BindView(R.id.time_picker)
    TimePicker timePicker;
    @BindView(R.id.rl_clock)
    RelativeLayout rlClock;
    AlarmClockDao dao;
    String time;
    String clockTime;
    Long clockId = 0L;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_reminder;
    }

    @Override
    protected void initToolbar(Bundle savedInstanceState) {
        setTitle("Reminder");
    }

    /**
     * show the clock state
     */
    @Override
    protected void initData() {
        dao = MySQLiteOpenHelper.getDaoSession(mContext).getAlarmClockDao();
        List<AlarmClock> datas = dao.loadAll();
        //if no clock added
        if(datas == null || datas.size() == 0){
            ivAddClock.setVisibility(View.VISIBLE);
            rlClock.setVisibility(View.GONE);
        }

        //show the previous added clock
        else {
            ivAddClock.setVisibility(View.GONE);
            rlClock.setVisibility(View.VISIBLE);
            AlarmClock clock = datas.get(0);
            clockId = clock.getId();
            tvClock.setText(clock.getTime());
        }

        //get date
        timePicker.setDescendantFocusability(TimePicker.FOCUS_BLOCK_DESCENDANTS);
        time = TimeUtils.date2String(TimeUtils.getNowDate(), "HH:mm");
        timePicker.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                Log.e("KK", "time is:" + hourOfDay + ":" + minute);
                time = format(hourOfDay) + ":" + format(minute);
            }
        });
    }

    /**
     * delete the clock
     */
    @OnClick(R.id.iv_delete_clock)
    public void deleteClock(){
        dao.deleteAll();
        ivAddClock.setVisibility(View.VISIBLE);
        rlClock.setVisibility(View.GONE);
    }

    // process the format 7:3-->07:03
    private String format(int x) {
        String s = "" + x;
        if (s.length() == 1) {
            s = "0" + s;
        }
        return s;
    }

    /**
     * set the clock
     */
    @OnClick(R.id.iv_add_clock)
    public void addClock(){
        //add clock
        AlarmClock clock = new AlarmClock();
        clock.setTime(time);
        if(clockId != 0){
            clock.setId(clockId);
        }

        //clockTime = TimeUtils.date2String(TimeUtils.getNowDate());

        //hint!! the pattern has chinese because all of team member's phone is made in china and other setting that we can not change
        //Due to the system, the phone just consider this format's pattern
        //our team do not try to act on the phone like made in EU
        //so the reminder may not work at other kind of phone
        clockTime = TimeUtils.date2String(TimeUtils.getNowDate(), "yyyy年MM月dd日 HH:mm:ss");

        String header = clockTime.substring(0, 12);
        String footer = clockTime.substring(clockTime.length() - 2, clockTime.length());
        Log.e("KK", header);
        Log.e("KK", footer);
        clockTime = new StringBuffer().append(header).append(time).append(":00").toString();
        Log.e("KK","set clock time:" + clockTime);
        Intent intent = new Intent(mContext, AlarmReceiver.class);
        intent.setAction("memo");
        PendingIntent pendingIntent = PendingIntent.getBroadcast(mContext, 0, intent, PendingIntent.FLAG_CANCEL_CURRENT);
        //call service
        AlarmManager manager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        //set time
        //manager.setExact(AlarmManager.RTC_WAKEUP, TimeUtils.string2Millis(clockTime), pendingIntent);

        manager.setExact(AlarmManager.RTC_WAKEUP, TimeUtils.string2Millis(clockTime, "yyyy年MM月dd日 HH:mm:ss"), pendingIntent);
        //hint!! the pattern has chinese because all of team member's phone is made in china and other setting that we can not change
        //Due to the system, the phone just consider this format's pattern
        //our team do not try to act on the phone like made in EU
        //so the reminder may not work at other kind of phone

        //manager.setExact(AlarmManager.RTC_WAKEUP, Long.parseLong(TimeUtils.millis2String(Long.parseLong(clockTime),date),pendingIntent));

        Long resultId = dao.insertOrReplace(clock);
        if(resultId != 0){
            //refresh page
            ivAddClock.setVisibility(View.GONE);
            rlClock.setVisibility(View.VISIBLE);
            tvClock.setText(clock.getTime());
        }
    }
}

