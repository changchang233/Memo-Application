package com.qk.medical;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.zhy.adapter.recyclerview.CommonAdapter;
import com.zhy.adapter.recyclerview.MultiItemTypeAdapter;
import com.zhy.adapter.recyclerview.base.ViewHolder;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;

/**
 * body condition selection page
 */
public class ConditionActivity extends BaseActivity {
    @BindView(R.id.rv_daily)
    RecyclerView rvDaily;
    private int clickPos;
    List<String> datas;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_daily;
    }

    /**
     * set the toolbar
     * @param savedInstanceState
     */
    @Override
    protected void initToolbar(Bundle savedInstanceState) {
        setTitle("Conditions");
    }

    /**
     * show the condition list
     */
    @Override
    protected void initData() {
        clickPos = getIntent().getIntExtra("pos", -1);
        rvDaily.setLayoutManager(new LinearLayoutManager(mContext));
        //show the conditon list
        datas = new ArrayList<>();
        datas.add("Allergies");
        datas.add("Breathing problems");
        datas.add("Ear problems");
        datas.add("Eye problems");
        datas.add("Gut, bowel and stomach");
        datas.add("Joint Pain");
        datas.add("Men's health");
        datas.add("Mental health");
        datas.add("Mouth problems");
        datas.add("Nose problems");
        datas.add("Skin and nail");
        datas.add("Sleep problems");
        datas.add("Woman's health");
        ConditionAdapter adapter = new ConditionAdapter(mContext, R.layout.item_condition, datas);
        rvDaily.setAdapter(adapter);
    }

    /**
     * update the list when add new item
     */
    class ConditionAdapter extends CommonAdapter<String> {

        public ConditionAdapter(Context context, int layoutId, List<String> datas) {
            super(context, layoutId, datas);
        }

        /**
         *Implement a sliding list
         * @param holder sliding list
         * @param s table's value
         * @param position
         */
        @Override
        protected void convert(ViewHolder holder, String s, int position) {
            holder.setText(R.id.tv_daily_item, s);
            CheckBox checkBox = holder.getView(R.id.cb_condition);
            checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if(isChecked){
                        checkBox.setSelected(true);
                        Intent intent = new Intent();
                        intent.putExtra("pos", clickPos);
                        intent.putExtra("data", datas.get(position));
                        setResult(RESULT_OK, intent);
                        finish();
                    }
                }
            });
        }
    }
}
