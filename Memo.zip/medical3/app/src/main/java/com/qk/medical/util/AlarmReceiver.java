package com.qk.medical.util;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Vibrator;
import android.util.Log;

import com.blankj.utilcode.util.ToastUtils;


/**
 * @ClassName: AlarmReceiver
 * @Description: AlarmReceiver
 * @Author:
 * @Version: 1.6.0
 */
public class AlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        ToastUtils.showLong("the time you set is arriving");
        Vibrator vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        if(vibrator != null){
            vibrator.vibrate(5000);
        }
        Log.e("KK", "the time you set is arriving");
    }
}
