package com.qk.medical.util;

import android.text.TextUtils;

/**
 * @ClassName: QKTextUtils
 * @Description:
 * @Author:
 * @Version: 1.6.0
 */
public class QKTextUtils {
    public static boolean isNullOrEmpty(String content){
        if(content == null){
            return true;
        }else if(TextUtils.isEmpty(content)){
            return true;
        }else {
            return false;
        }
    }
}
