package com.qk.medical.toDB;

import java.util.List;

/**
 * add things to db
 */
public class addToDB implements toDB {

    @Override
    public void transactionToDB(List datas, Object table) {
        datas.add(0, table);
    }

    public void addAll(List datas, List result) {

        datas.addAll(result);
    }
}