package com.qk.medical;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.zhy.adapter.recyclerview.CommonAdapter;
import com.zhy.adapter.recyclerview.MultiItemTypeAdapter;
import com.zhy.adapter.recyclerview.base.ViewHolder;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;

/**
 * @ClassName: DailyRecordActivity
 * @Description: Daily Record select page
 * @Author:
 * @Version: 1.6.0
 */
public class DailyRecordActivity extends BaseActivity {
    @BindView(R.id.rv_daily)
    RecyclerView rvDaily;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_daily;
    }

    @Override
    protected void initToolbar(Bundle savedInstanceState) {
        setTitle("Daily Health Record");
    }

    @Override
    protected void initData() {
        //show the daily record list
        List<String> datas = new ArrayList<>();
        datas.add("Body temperature");
        datas.add("Blood glucose");
        datas.add("Blood press");
        datas.add("Breathe");
        datas.add("Pulse");
        DailyAdapter adapter = new DailyAdapter(mContext, R.layout.item_daily_record, datas);
        rvDaily.setLayoutManager(new LinearLayoutManager(mContext));
        rvDaily.setAdapter(adapter);

        //click one of the five  daily record
        adapter.setOnItemClickListener(new MultiItemTypeAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, RecyclerView.ViewHolder viewHolder, int i) {
                goNext(i);
            }

            @Override
            public boolean onItemLongClick(View view, RecyclerView.ViewHolder viewHolder, int i) {
                return false;
            }
        });
    }

    /**
     * select add which kind of item
     * @param pos
     */
    private void goNext(int pos){
        switch (pos){
            case 0:
                goActivity(new Intent(mContext, BodyTemperatureActivity.class));
                break;
            case 1:
                goActivity(new Intent(mContext, BloodGlucoseActivity.class));
                break;
            case 2:
                goActivity(new Intent(mContext, BloodPressActivity.class));
                break;
            case 3:
                goActivity(new Intent(mContext, BreatheActivity.class));
                break;
            case 4:
                goActivity(new Intent(mContext, PulseActivity.class));
                break;
        }
    }


    /**
     * adapt list
     */
    class DailyAdapter extends CommonAdapter<String> {

        public DailyAdapter(Context context, int layoutId, List<String> datas) {
            super(context, layoutId, datas);
        }

        @Override
        protected void convert(ViewHolder holder, String s, int position) {
            holder.setText(R.id.tv_daily_item, s);
        }
    }

}
