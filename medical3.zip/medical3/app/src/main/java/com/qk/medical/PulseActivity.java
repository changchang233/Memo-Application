package com.qk.medical;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.blankj.utilcode.util.ToastUtils;
import com.qk.medical.database.operation.MySQLiteOpenHelper;
import com.qk.medical.database.tableInfor.BloodPressure;
import com.qk.medical.database.tableInfor.Pulse;
import com.qk.medical.gen.BloodPressureDao;
import com.qk.medical.gen.PulseDao;
import com.qk.medical.toDB.addToDB;
import com.qk.medical.toDB.deleteToDB;
import com.zhy.adapter.recyclerview.CommonAdapter;
import com.zhy.adapter.recyclerview.base.ViewHolder;

import java.util.List;

import butterknife.BindView;

/**
 * @ClassName: ReminderActivity
 * @Description:
 * @Author:
 * @Version: 1.6.0
 */
public class PulseActivity extends BaseActivity {
    @BindView(R.id.btn_add)
    Button btnAdd;
    @BindView(R.id.rv_daily)
    RecyclerView recyclerView;
    private PulseDao dao;
    private List<Pulse> datas;
    private PulseAdapter adapter;
    addToDB add= new addToDB();
    deleteToDB delete= new deleteToDB();

    @Override
    protected int getLayoutId() {
        return R.layout.activity_record;
    }

    @Override
    protected void initToolbar(Bundle savedInstanceState) {
        setTitle("Pulse Record");
    }

    @Override
    protected void initData() {
        //gain the data
        btnAdd.setOnClickListener(v -> {
            //go to other page
            startActivityForResult(new Intent(mContext, PulseAddActivity.class), 101);
        });

        //set db and show record List, and record list can update by transaction
        dao = MySQLiteOpenHelper.getDaoSession(mContext).getPulseDao();
        recyclerView.setLayoutManager(new LinearLayoutManager(mContext));
        datas = dao.queryBuilder().orderDesc(PulseDao.Properties.Id).build().list();
        adapter = new PulseAdapter(mContext, R.layout.item_body_temp, datas);
        recyclerView.setAdapter(adapter);
    }

    /**
     * when end this page's activity
     * save data to database
     * @param requestCode
     * @param resultCode
     * @param data
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 101 && resultCode == RESULT_OK && data != null){
            String temp = data.getStringExtra("temp");
            String time = data.getStringExtra("time");
            String note = data.getStringExtra("note");
            Long resultId = data.getLongExtra("id", 0L);
            Pulse pulse = new Pulse();
            pulse.setPulse(temp);
            pulse.setDate(time);
            pulse.setNotes(note);
            pulse.setId(resultId);
            add.transactionToDB(datas,pulse);
            adapter.notifyDataSetChanged();//Notifies the Activity to update the ListView
        }
    }

    /**
     * Adapter for the pulse list
     */
    class PulseAdapter extends CommonAdapter<Pulse> {

        public PulseAdapter(Context context, int layoutId, List<Pulse> datas) {
            super(context, layoutId, datas);
        }

        /**
         *Implement a sliding list
         * @param holder sliding list
         * @param Pulse table's value
         * @param position
         */
        @Override
        protected void convert(ViewHolder holder, Pulse Pulse, int position) {
            Log.e("KK", "" + Pulse.getId());
            holder.setText(R.id.tv_text_one, "time: " + Pulse.getDate());
            holder.setText(R.id.tv_text_two, "pulse: " + Pulse.getPulse() + " mmHg");
            holder.setText(R.id.tv_text_three, "note: " + Pulse.getNotes());
            holder.setOnClickListener(R.id.iv_item_delete, new View.OnClickListener() {
                //when click delete
                @Override
                public void onClick(View v) {
                    delete.transactionToDB(datas,Pulse);
                    delete.delete(dao,Pulse);
                    ToastUtils.showShort("delete");
                    adapter.notifyDataSetChanged();
                }
            });
        }
    }
}
