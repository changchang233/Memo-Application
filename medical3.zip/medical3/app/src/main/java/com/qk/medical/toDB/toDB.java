package com.qk.medical.toDB;

import java.util.List;

public interface toDB {
    void transactionToDB(List datas, Object table);
}
