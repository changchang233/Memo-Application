/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.qk.medical.database.tableInfor;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;

import java.time.LocalDateTime;
import java.util.Date;
import org.greenrobot.greendao.annotation.Generated;

/**
 *
 * @author xuxiaoyue
 */
@Entity
public class BodyTemperature {
    @Id
    private Long id;
    private String bodyTemp;

    private String date;
    private String notes;
    @Generated(hash = 371278725)
    public BodyTemperature(Long id, String bodyTemp, String date, String notes) {
        this.id = id;
        this.bodyTemp = bodyTemp;
        this.date = date;
        this.notes = notes;
    }
    @Generated(hash = 1527592006)
    public BodyTemperature() {
    }
    public Long getId() {
        return this.id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getBodyTemp() {
        return this.bodyTemp;
    }
    public void setBodyTemp(String bodyTemp) {
        this.bodyTemp = bodyTemp;
    }
    public String getDate() {
        return this.date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public String getNotes() {
        return this.notes;
    }
    public void setNotes(String notes) {
        this.notes = notes;
    }

}
