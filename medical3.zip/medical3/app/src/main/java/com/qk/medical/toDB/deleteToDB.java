package com.qk.medical.toDB;

import org.greenrobot.greendao.AbstractDao;

import java.util.List;

/**
 * delete things from db
 */
public class deleteToDB implements toDB {
    @Override
    public void transactionToDB(List datas, Object table) {
        datas.remove(table);
    }
    public void delete(AbstractDao dao, Object table) {
        dao.delete(table);
    }
}
