/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.qk.medical.database.tableInfor;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Generated;


/**
 *
 * @author xuxiaoyue
 */
@Entity
public class AlarmClock {
    @Id
    private Long id;
    private String time;
    @Generated(hash = 105698917)
    public AlarmClock(Long id, String time) {
        this.id = id;
        this.time = time;
    }
    @Generated(hash = 238396230)
    public AlarmClock() {
    }
    public Long getId() {
        return this.id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getTime() {
        return this.time;
    }
    public void setTime(String time) {
        this.time = time;
    }

}
