/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.qk.medical.database.tableInfor;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Generated;

/**
 *
 * @author xuxiaoyue
 */
@Entity
public class BloodGlucose {
    @Id
    private Long id;
    private String bloodGlu;
    private String date;
    private String notes;
    @Generated(hash = 1735482415)
    public BloodGlucose(Long id, String bloodGlu, String date, String notes) {
        this.id = id;
        this.bloodGlu = bloodGlu;
        this.date = date;
        this.notes = notes;
    }
    @Generated(hash = 1275899084)
    public BloodGlucose() {
    }
    public Long getId() {
        return this.id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getBloodGlu() {
        return this.bloodGlu;
    }
    public void setBloodGlu(String bloodGlu) {
        this.bloodGlu = bloodGlu;
    }
    public String getDate() {
        return this.date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public String getNotes() {
        return this.notes;
    }
    public void setNotes(String notes) {
        this.notes = notes;
    }
}
