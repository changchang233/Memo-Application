/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.qk.medical.database.tableInfor;

import org.greenrobot.greendao.annotation.Entity;

import java.time.LocalDateTime;
import java.util.Date;
import org.greenrobot.greendao.annotation.Generated;
import org.greenrobot.greendao.annotation.Id;

/**
 *
 * @author xuxiaoyue
 */
@Entity()
public class BloodPressure {
    @Id
    private Long id;
    private String bloodPres;
    private String date;
    private String notes;
    @Generated(hash = 406413424)
    public BloodPressure(Long id, String bloodPres, String date, String notes) {
        this.id = id;
        this.bloodPres = bloodPres;
        this.date = date;
        this.notes = notes;
    }
    @Generated(hash = 1446110616)
    public BloodPressure() {
    }
    public Long getId() {
        return this.id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getBloodPres() {
        return this.bloodPres;
    }
    public void setBloodPres(String bloodPres) {
        this.bloodPres = bloodPres;
    }
    public String getDate() {
        return this.date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public String getNotes() {
        return this.notes;
    }
    public void setNotes(String notes) {
        this.notes = notes;
    }

}
