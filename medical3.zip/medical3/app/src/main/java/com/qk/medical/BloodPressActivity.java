package com.qk.medical;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.blankj.utilcode.util.ActivityUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.qk.medical.database.operation.MySQLiteOpenHelper;
import com.qk.medical.database.tableInfor.BloodPressure;
import com.qk.medical.gen.BloodPressureDao;
import com.qk.medical.toDB.addToDB;
import com.qk.medical.toDB.deleteToDB;
import com.zhy.adapter.recyclerview.CommonAdapter;
import com.zhy.adapter.recyclerview.base.ViewHolder;

import java.util.List;

import butterknife.BindView;

/**
 * @ClassName: BloodPressActivity
 * @Description: Blood Press page
 * @Author:
 * @Version: 1.6.0
 */
public class BloodPressActivity extends BaseActivity {
    @BindView(R.id.btn_add)
    Button btnAdd;
    @BindView(R.id.rv_daily)
    RecyclerView recyclerView;
    private BloodPressureDao dao;
    private List<BloodPressure> datas;
    private BloodPressAdapter adapter;
    addToDB add= new addToDB();
    deleteToDB delete= new deleteToDB();

    @Override
    protected int getLayoutId() {
        return R.layout.activity_record;
    }

    @Override
    protected void initToolbar(Bundle savedInstanceState) {
        setTitle("Blood Press Record");
    }

    @Override
    protected void initData() {
        //get and show the data in db
        //set db and show record List, and record list can update by transaction
        btnAdd.setOnClickListener(v -> startActivityForResult(new Intent(mContext, BloodPressAddActivity.class), 101));
        dao = MySQLiteOpenHelper.getDaoSession(mContext).getBloodPressureDao();
        recyclerView.setLayoutManager(new LinearLayoutManager(mContext));
        datas = dao.queryBuilder().orderDesc(BloodPressureDao.Properties.Id).build().list();
        adapter = new BloodPressAdapter(mContext, R.layout.item_body_temp, datas);
        recyclerView.setAdapter(adapter);
    }

    /**
     * The submodule returns some data to the main Activity for processing
     * @param requestCode confirm the data is returned from which activity
     * @param resultCode RESULT OK > call back
     *                   RESULT CANCELLED > no call back
     * @param data data that passes
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 101 && resultCode == RESULT_OK && data != null){
            String temp = data.getStringExtra("temp");
            String time = data.getStringExtra("time");
            String note = data.getStringExtra("note");
            Long resultId = data.getLongExtra("id", 0L);
            BloodPressure bloodPressure = new BloodPressure();
            bloodPressure.setBloodPres(temp);
            bloodPressure.setDate(time);
            bloodPressure.setNotes(note);
            bloodPressure.setId(resultId);
            add.transactionToDB(datas,bloodPressure);
            //datas.add(0, bloodPressure);
            adapter.notifyDataSetChanged();
        }
    }

    class BloodPressAdapter extends CommonAdapter<BloodPressure>{

        public BloodPressAdapter(Context context, int layoutId, List<BloodPressure> datas) {
            super(context, layoutId, datas);
        }

        /**
         *Implement a sliding list
         * @param holder sliding list
         * @param bloodPressure table's value
         * @param position
         */
        @Override
        protected void convert(ViewHolder holder, BloodPressure bloodPressure, int position) {
            holder.setText(R.id.tv_text_one, "time: " + bloodPressure.getDate());
            holder.setText(R.id.tv_text_two, "GLU: " + bloodPressure.getBloodPres() + " mmHg");
            holder.setText(R.id.tv_text_three, "note: " + bloodPressure.getNotes());
            holder.setOnClickListener(R.id.iv_item_delete, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    delete.transactionToDB(datas,bloodPressure);
                    delete.delete(dao,bloodPressure);
                    //datas.remove(bloodPressure);
                    //dao.delete(bloodPressure);
                    ToastUtils.showShort("delete successfully");
                    adapter.notifyDataSetChanged();
                }
            });
        }
    }
}
