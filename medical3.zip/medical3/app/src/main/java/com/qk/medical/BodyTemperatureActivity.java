package com.qk.medical;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.blankj.utilcode.util.ToastUtils;
import com.qk.medical.database.operation.MySQLiteOpenHelper;
import com.qk.medical.database.tableInfor.BloodPressure;
import com.qk.medical.database.tableInfor.BodyTemperature;
import com.qk.medical.database.tableInfor.Breathe;
import com.qk.medical.gen.BodyTemperatureDao;
import com.qk.medical.toDB.addToDB;
import com.qk.medical.toDB.deleteToDB;
import com.zhy.adapter.recyclerview.CommonAdapter;
import com.zhy.adapter.recyclerview.base.ViewHolder;

import java.util.List;

import butterknife.BindView;

/**
 * @ClassName: BodyTemperatureActivity
 * @Description: Body Temperature page
 * @Author:
 * @Version: 1.6.0
 */
public class BodyTemperatureActivity extends BaseActivity {
    @BindView(R.id.btn_add)
    Button btnAdd;
    @BindView(R.id.rv_daily)
    RecyclerView rvBody;
    BodyTemperatureDao dao;
    List<BodyTemperature> datas;
    BodyTemAdapter bodyTemAdapter;
    addToDB add= new addToDB();
    deleteToDB delete= new deleteToDB();

    @Override
    protected int getLayoutId() {
        return R.layout.activity_record;
    }

    @Override
    protected void initToolbar(Bundle savedInstanceState) {
        setTitle("Body Temperature Record");
    }

    @Override
    protected void initData() {
        //get and show the data in db
        //set db and show record List, and record list can update by transaction
        dao = MySQLiteOpenHelper.getDaoSession(mContext).getBodyTemperatureDao();
        datas = dao.queryBuilder().orderDesc(BodyTemperatureDao.Properties.Id).build().list();
        btnAdd.setOnClickListener(v -> startActivityForResult(new Intent(mContext,BodyTemperatureAddActivity.class), 101));
        rvBody.setLayoutManager(new LinearLayoutManager(mContext));
        bodyTemAdapter = new BodyTemAdapter(mContext, R.layout.item_body_temp, datas);
        rvBody.setAdapter(bodyTemAdapter);
    }

    /**
     * The submodule returns some data to the main Activity for processing
     * @param requestCode confirm the data is returned from which activity
     * @param resultCode RESULT OK > call back
     *                   RESULT CANCELLED > no call back
     * @param data data that passes
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 101 && resultCode == RESULT_OK && data != null){

            String temp = data.getStringExtra("temp");
            String time = data.getStringExtra("time");
            String note = data.getStringExtra("note");
            Long resultId = data.getLongExtra("id", 0L);
            BodyTemperature bodyTemperature = new BodyTemperature();
            bodyTemperature.setBodyTemp(temp);
            bodyTemperature.setDate(time);
            bodyTemperature.setNotes(note);
            bodyTemperature.setId(resultId);
            add.transactionToDB(datas,bodyTemperature);
            //datas.add(0, bodyTemperature);
            bodyTemAdapter.notifyDataSetChanged();
        }
    }

    class BodyTemAdapter extends CommonAdapter<BodyTemperature> {

        public BodyTemAdapter(Context context, int layoutId, List<BodyTemperature> datas) {
            super(context, layoutId, datas);
        }
        /**
         *Implement a sliding list
         * @param holder sliding list
         * @param bodyTemperature table's value
         * @param position
         */
        @Override
        protected void convert(ViewHolder holder, BodyTemperature bodyTemperature, int position) {
            holder.setText(R.id.tv_text_one, "time: " + bodyTemperature.getDate());
            holder.setText(R.id.tv_text_two, "temperature: " + bodyTemperature.getBodyTemp() + " ℃");
            holder.setText(R.id.tv_text_three, "note: " + bodyTemperature.getNotes());
            holder.setOnClickListener(R.id.iv_item_delete, new View.OnClickListener() {

                //when click delete
                @Override
                public void onClick(View v) {
                    delete.transactionToDB(datas,bodyTemperature);
                    delete.delete(dao,bodyTemperature);
                    //datas.remove(bodyTemperature);
                    //dao.delete(bodyTemperature);
                    ToastUtils.showShort("delete successfully");
                    bodyTemAdapter.notifyDataSetChanged();
                }
            });
        }
    }
}
