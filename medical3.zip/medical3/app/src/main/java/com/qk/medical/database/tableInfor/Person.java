/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.qk.medical.database.tableInfor;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;

import java.util.Date;
import org.greenrobot.greendao.annotation.Generated;

/**
 *
 * @author xuxiaoyue
 */
@Entity
public class Person {
    private String name;
    private String birth;
    private String sex;
    private String marriage;
    private String national;
    private String bloType;
    private String child;
    private String smoHist;
    private String alcoh;
    private String allergies;
    private String famiHist;
    @Id
    private Long id;
    @Generated(hash = 1789466169)
    public Person(String name, String birth, String sex, String marriage,
            String national, String bloType, String child, String smoHist,
            String alcoh, String allergies, String famiHist, Long id) {
        this.name = name;
        this.birth = birth;
        this.sex = sex;
        this.marriage = marriage;
        this.national = national;
        this.bloType = bloType;
        this.child = child;
        this.smoHist = smoHist;
        this.alcoh = alcoh;
        this.allergies = allergies;
        this.famiHist = famiHist;
        this.id = id;
    }
    @Generated(hash = 1024547259)
    public Person() {
    }
    public String getName() {
        return this.name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getBirth() {
        return this.birth;
    }
    public void setBirth(String birth) {
        this.birth = birth;
    }
    public String getSex() {
        return this.sex;
    }
    public void setSex(String sex) {
        this.sex = sex;
    }
    public String getMarriage() {
        return this.marriage;
    }
    public void setMarriage(String marriage) {
        this.marriage = marriage;
    }
    public String getNational() {
        return this.national;
    }
    public void setNational(String national) {
        this.national = national;
    }
    public String getBloType() {
        return this.bloType;
    }
    public void setBloType(String bloType) {
        this.bloType = bloType;
    }
    public String getChild() {
        return this.child;
    }
    public void setChild(String child) {
        this.child = child;
    }
    public String getSmoHist() {
        return this.smoHist;
    }
    public void setSmoHist(String smoHist) {
        this.smoHist = smoHist;
    }
    public String getAlcoh() {
        return this.alcoh;
    }
    public void setAlcoh(String alcoh) {
        this.alcoh = alcoh;
    }
    public String getAllergies() {
        return this.allergies;
    }
    public void setAllergies(String allergies) {
        this.allergies = allergies;
    }
    public String getFamiHist() {
        return this.famiHist;
    }
    public void setFamiHist(String famiHist) {
        this.famiHist = famiHist;
    }
    public Long getId() {
        return this.id;
    }
    public void setId(Long id) {
        this.id = id;
    }

}
