package com.qk.medical;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.blankj.utilcode.util.ToastUtils;

import butterknife.BindView;
import butterknife.ButterKnife;


/**
 * File descripition: basic activity's options
 * it contains some basic page layout and activity
 */
public abstract class BaseActivity extends AppCompatActivity {
    protected final String TAG = this.getClass().getSimpleName();
    public Context mContext;

    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.ll_title_menu)
    LinearLayout ll_title_menu;//Layout of the left back button
    @BindView(R.id.iv_left_back)
    ImageView ivLeftBack;//Layout of the left return button
    @BindView(R.id.ll_search)
    RelativeLayout flRight;//Layout of the right back button
    @BindView(R.id.tv_cart_num)
    TextView tvCartNum;
    @BindView(R.id.iv_right_img)
    ImageView ivRight;//right icon
    @BindView(R.id.tv_title_left)
    TextView tv_title_left;//left text
    @BindView(R.id.toolbar_title)
    TextView toolbar_title;//middle text
    @BindView(R.id.tv_title_right)
    TextView tv_title_right;//rigth text


    /**
     * call it when activity is called
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;
        setContentView(getLayoutId());
        ButterKnife.bind(this);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        showLeft(true);
        showRight(false);
        setDarkStatusIcon(true);
        ll_title_menu.setOnClickListener(v->{
            onBackPressed();
        });
        this.initToolbar(savedInstanceState);
        this.initData();
    }

    /**
     * do activity
     * @param intent do which activity
     */
    protected void goActivity(Intent intent){
        startActivity(intent);
    }

    /**
     * fix the font size
     * @return
     */
    @Override
    public Resources getResources() {
        Resources resources = super.getResources();
        if(resources != null){
            Configuration config = new Configuration();
            config.setToDefaults();
            resources.updateConfiguration(config, resources.getDisplayMetrics());
        }
        return resources;
    }

    /**
     * set title
     * @param title the title
     */
    protected void setTitle(String title) {
        toolbar_title.setText(title);
    }


    /**
     * set right side text
     * @param title
     */
    protected void setRightText(String title){
        tv_title_right.setText(title);
    }

    /**
     * when click on left button, goto page
     */
    protected void setOnRightClickListener(View.OnClickListener onRightClickListener){
        tv_title_right.setOnClickListener(v -> {
            if(onRightClickListener != null){
                onRightClickListener.onClick(v);
            }
        });
    }

    /**
     * whether show the text
     * @param isShowRight
     */
    protected void showRight(boolean isShowRight) {
        if(isShowRight){
            tv_title_right.setVisibility(View.VISIBLE);
        }else {
            tv_title_right.setVisibility(View.GONE);
        }
    }



    /**
     * Main page doesnt show
     * whether show the left side return button
     * @param isShow
     */
    protected void showLeft(boolean isShow) {
        if(isShow){
            ll_title_menu.setVisibility(View.VISIBLE);
        }else {
            ll_title_menu.setVisibility(View.GONE);
        }
    }



    /**
     * whether show the left text
     * @param isShow true : show  false: not show
     */
    protected void showLeftText(boolean isShow){
        if(isShow){
            tv_title_left.setVisibility(View.VISIBLE);
        }else {
            tv_title_left.setVisibility(View.GONE);
        }
    }

    /**
     * gain the lay out ID
     *
     * @return
     */
    protected abstract int getLayoutId();

    /**
     * set the title title
     * @param savedInstanceState
     */
    protected abstract void initToolbar(Bundle savedInstanceState);

    /**
     * initial data
     */
    protected abstract void initData();


    /**
     * set the button's color whether to black
     */
    protected void setDarkStatusIcon(boolean dark) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            View decorView = getWindow().getDecorView();
            if (decorView == null) return;

            int vis = decorView.getSystemUiVisibility();
            if (dark) {
                vis |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            } else {
                vis &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            }
            decorView.setSystemUiVisibility(vis);
        }
    }

    /**
     * show the toast
     *
     * @param str the str in toast
     */
    public void showToast(String str) {
        ToastUtils.showShort(str);
    }

    public void showLongToast(String str) {
//        ToastUtils.showLong(str);
    }

    /**
     * end activity
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();

    }
}
