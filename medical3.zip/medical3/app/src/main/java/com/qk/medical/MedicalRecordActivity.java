package com.qk.medical;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.blankj.utilcode.util.ToastUtils;
import com.qk.medical.database.operation.MySQLiteOpenHelper;
import com.qk.medical.database.tableInfor.MedicalHistory;
import com.qk.medical.gen.MedicalHistoryDao;
import com.qk.medical.toDB.addToDB;
import com.qk.medical.toDB.deleteToDB;
import com.qk.medical.util.QKTextUtils;
import com.zhy.adapter.recyclerview.CommonAdapter;
import com.zhy.adapter.recyclerview.MultiItemTypeAdapter;
import com.zhy.adapter.recyclerview.base.ViewHolder;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * @ClassName: MedicalRecordActivity
 * @Description: show the history list and turn page to add history
 *               edit history
 * @Author:
 * @Version: 1.6.0
 */
public class MedicalRecordActivity extends BaseActivity {
    @BindView(R.id.et_search_content)
    EditText etSearchContent;
    @BindView(R.id.btn_search)
    Button btnSearch;
    @BindView(R.id.rv_medical_record)
    RecyclerView rvMedicalRecord;
    private MedicalHistoryDao dao;
    private HealthRecordAdapter adapter;
    private List<MedicalHistory> datas;
    addToDB add = new addToDB();
    deleteToDB delete= new deleteToDB();

    @Override
    protected int getLayoutId() {
        return R.layout.activity_medical_record;
    }

    @Override
    protected void initToolbar(Bundle savedInstanceState) {
        setTitle("Medical Health Record");
        showRight(true);
        setRightText("ADD");
        setOnRightClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(mContext, EditMedicalRecordActivity.class), 101);
            }
        });
    }

    /**
     * The submodule returns some data to the main Activity for processing
     * @param requestCode confirm the data is returned from which activity
     * @param resultCode RESULT OK > call back
     *                   RESULT CANCELLED > no call back
     * @param data data that passes
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 101 && resultCode == RESULT_OK && data != null){
            MedicalHistory history = new MedicalHistory();
            String conditionOne = data.getStringExtra("conditionOne");
            String conditionTwo = data.getStringExtra("conditionTwo");
            String medication = data.getStringExtra("medication");
            String medicationTwo = data.getStringExtra("medicationTwo");
            String date = data.getStringExtra("date");
            String dateTwo = data.getStringExtra("dateTwo");
            String note = data.getStringExtra("note");
            Long resultId = data.getLongExtra("id", 0L);
            int pos = data.getIntExtra("pos", -1);
            history.setSymptom(conditionOne);
            history.setSymptom_two(conditionTwo);
            history.setMedications(medication);
            history.setMedications_two(medicationTwo);
            history.setDateOftaking(date);
            history.setDateOfstop(dateTwo);
            history.setNotes(note);
            history.setId(resultId);
            if(pos >= 0){
                MedicalHistory newHistory = datas.get(pos);
                newHistory.setSymptom(conditionOne);
                newHistory.setSymptom_two(conditionTwo);
                newHistory.setMedications(medication);
                newHistory.setMedications_two(medicationTwo);
                newHistory.setDateOftaking(date);
                newHistory.setDateOfstop(dateTwo);
                newHistory.setNotes(note);
                newHistory.setId(resultId);
                adapter.notifyItemChanged(pos);
            }else {
                add.transactionToDB(datas,history);
                //datas.add(0, history);
            }
            adapter.notifyDataSetChanged();
        }
    }

    @Override
    protected void initData() {
        rvMedicalRecord.setLayoutManager(new LinearLayoutManager(mContext));
        dao = MySQLiteOpenHelper.getDaoSession(mContext).getMedicalHistoryDao();
        datas = dao.queryBuilder().orderDesc(MedicalHistoryDao.Properties.Id).build().list();
        adapter = new HealthRecordAdapter(mContext, R.layout.item_body_temp, datas);
        rvMedicalRecord.setAdapter(adapter);
        adapter.setOnItemClickListener(new MultiItemTypeAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, RecyclerView.ViewHolder holder, int position) {
                Intent intent = new Intent(mContext, EditMedicalRecordActivity.class);
                intent.putExtra("id", datas.get(position).getId());
                intent.putExtra("pos", position);
                startActivityForResult(intent, 101);
            }

            @Override
            public boolean onItemLongClick(View view, RecyclerView.ViewHolder holder, int position) {
                return false;
            }
        });

        etSearchContent.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(QKTextUtils.isNullOrEmpty(s.toString())){
                    //delete data reload
                    datas = dao.queryBuilder().orderDesc(MedicalHistoryDao.Properties.Id).build().list();
                    adapter.notifyDataSetChanged();
                }
            }
        });
    }

    //when click search
    @OnClick(R.id.btn_search)
    public void clickSearch(){
        String time = etSearchContent.getText().toString().trim();
        if(QKTextUtils.isNullOrEmpty(time)){
            ToastUtils.showShort("Please input time");
            return;
        }
        List<MedicalHistory> result = dao.queryBuilder()
                .where(MedicalHistoryDao.Properties.DateOftaking.eq(time)).build().list();
        if(result == null || result.size() == 0){
            ToastUtils.showShort("No result found");
            return;
        }
        datas.clear();
        add.addAll(datas,result);
        //datas.addAll(result);
        adapter.notifyDataSetChanged();

    }

    class HealthRecordAdapter extends CommonAdapter<MedicalHistory> {

        public HealthRecordAdapter(Context context, int layoutId, List<MedicalHistory> datas) {
            super(context, layoutId, datas);
        }

        @Override
        protected void convert(ViewHolder holder, MedicalHistory medical, int position) {
            holder.setText(R.id.tv_text_one, "condition: " + medical.getSymptom());
            holder.setText(R.id.tv_text_two, "medication: " + medical.getMedications());
            holder.setText(R.id.tv_text_three, "date: " + medical.getDateOftaking());
            holder.setOnClickListener(R.id.iv_item_delete, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    delete.transactionToDB(datas,medical);
                    delete.delete(dao,medical);
                    //dao.delete(bloodPressure);
                    //datas.remove(bloodPressure);
                    ToastUtils.showShort("delete record");
                    adapter.notifyItemRemoved(position);
                }
            });
        }
    }
}
