/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.qk.medical.database.tableInfor;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Generated;

import java.io.Serializable;

/**
 *
 * @author xuxiaoyue
 */
@Entity
public class MedicalHistory {
    @Id
    private Long id;
    private String medications;
    private String medications_two;
    private String symptom;
    private String symptom_two;
    private String dateOftaking;
    private String dateOfstop;
    private String notes;
    @Generated(hash = 1036101872)
    public MedicalHistory(Long id, String medications, String medications_two,
            String symptom, String symptom_two, String dateOftaking,
            String dateOfstop, String notes) {
        this.id = id;
        this.medications = medications;
        this.medications_two = medications_two;
        this.symptom = symptom;
        this.symptom_two = symptom_two;
        this.dateOftaking = dateOftaking;
        this.dateOfstop = dateOfstop;
        this.notes = notes;
    }
    @Generated(hash = 336814418)
    public MedicalHistory() {
    }
    public Long getId() {
        return this.id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getMedications() {
        return this.medications;
    }
    public void setMedications(String medications) {
        this.medications = medications;
    }
    public String getMedications_two() {
        return this.medications_two;
    }
    public void setMedications_two(String medications_two) {
        this.medications_two = medications_two;
    }
    public String getSymptom() {
        return this.symptom;
    }
    public void setSymptom(String symptom) {
        this.symptom = symptom;
    }
    public String getSymptom_two() {
        return this.symptom_two;
    }
    public void setSymptom_two(String symptom_two) {
        this.symptom_two = symptom_two;
    }
    public String getDateOftaking() {
        return this.dateOftaking;
    }
    public void setDateOftaking(String dateOftaking) {
        this.dateOftaking = dateOftaking;
    }
    public String getDateOfstop() {
        return this.dateOfstop;
    }
    public void setDateOfstop(String dateOfstop) {
        this.dateOfstop = dateOfstop;
    }
    public String getNotes() {
        return this.notes;
    }
    public void setNotes(String notes) {
        this.notes = notes;
    }

}
