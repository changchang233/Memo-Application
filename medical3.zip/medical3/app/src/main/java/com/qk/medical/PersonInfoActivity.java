package com.qk.medical;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import com.blankj.utilcode.util.ToastUtils;
import com.qk.medical.database.operation.MySQLiteOpenHelper;
import com.qk.medical.database.tableInfor.Person;
import com.qk.medical.gen.PersonDao;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * @ClassName: PersonInfoActivity
 * @Description: edit, show person info
 * @Author:
 * @Version: 1.6.0
 */
public class PersonInfoActivity extends BaseActivity {

    @BindView(R.id.et_name)
    EditText etName;
    @BindView(R.id.et_birthday)
    EditText etBirthday;
    @BindView(R.id.rg_sex)
    RadioGroup rgSex;
    @BindView(R.id.rg_blood)
    RadioGroup rgBlood;
    @BindView(R.id.et_nationality)
    EditText etNationality;
    @BindView(R.id.et_allergies)
    EditText etAllergies;
    @BindView(R.id.et_fam)
    EditText etFam;
    @BindView(R.id.et_smoke)
    EditText etSmoke;
    @BindView(R.id.rg_alcohol)
    RadioGroup rgAlcohol;
    @BindView(R.id.rg_mc)
    RadioGroup rgMc;
    @BindView(R.id.rg_child)
    RadioGroup rgChild;
    String sex = "";
    PersonDao dao;
    @BindView(R.id.rb_sex_one)
    RadioButton rbSexOne;
    @BindView(R.id.rb_sex_two)
    RadioButton rbSexTwo;
    @BindView(R.id.rb_blood_one)
    RadioButton rbBloodOne;
    @BindView(R.id.rb_blood_two)
    RadioButton rbBloodTwo;
    @BindView(R.id.rb_blood_three)
    RadioButton rbBloodThree;
    @BindView(R.id.rb_blood_four)
    RadioButton rbBloodFour;
    @BindView(R.id.rb_alcohol_one)
    RadioButton rbAlcoholOne;
    @BindView(R.id.rb_alcohol_two)
    RadioButton rbAlcoholTwo;
    @BindView(R.id.rb_mc_one)
    RadioButton rbMcOne;
    @BindView(R.id.rb_mc_two)
    RadioButton rbMcTwo;
    @BindView(R.id.rb_child_one)
    RadioButton rbChildOne;
    @BindView(R.id.rb_child_two)
    RadioButton rbChildTwo;
    Long personId = 0L;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_person_info;
    }

    /**
     * set the toolbar's title and save button
     * when click the save button, save this page's data
     * @param savedInstanceState
     */
    @Override
    protected void initToolbar(Bundle savedInstanceState) {
        setTitle("Person Info");
        showRight(true);
        setRightText("Save");
        setOnRightClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //save the data
                saveData();
            }
        });
    }

    /**
     * show the content of the page when open person page
     */
    @Override
    protected void initData() {
        dao = MySQLiteOpenHelper.getDaoSession(mContext).getPersonDao();
        List<Person> personList = dao.queryBuilder().build().list();
        if(personList != null && personList.size() != 0){
            Person person = personList.get(0);
            personId = person.getId();
            bindData(person);
        }
    }

    /**
     * show the personal info according to the database's record
     * @param person
     */
    private void bindData(Person person) {
        if (person == null) {
            Log.e("KK", "date is null");
            return;
        }
        etName.setText(person.getName());
        etBirthday.setText(person.getBirth());
        etAllergies.setText(person.getAllergies());
        etFam.setText(person.getFamiHist());
        etNationality.setText(person.getNational());
        etSmoke.setText(person.getSmoHist());
        if (person.getSex().equals("Male")) {
            rbSexOne.setChecked(true);
        }else {
            rbSexTwo.setChecked(true);
        }

        //show blood type,alcoh, marriage in button
        if(person.getBloType().equals("A")){
            rbBloodOne.setChecked(true);
        }else if(person.getBloType().equals("B")){
            rbBloodTwo.setChecked(true);
        }else if(person.getBloType().equals("AB")){
            rbBloodThree.setChecked(true);
        }else if(person.getBloType().equals("O")){
            rbBloodFour.setChecked(true);
        }

        if(person.getAlcoh().equals("YES")){
            rbAlcoholOne.setChecked(true);
        }else {
            rbAlcoholTwo.setChecked(true);
        }

        if(person.getMarriage().equals("SINGLE")){
            rbMcOne.setChecked(true);
        }else {
            rbMcTwo.setChecked(true);
        }

        if(person.getChild().equals("YES")){
            rbChildOne.setChecked(true);
        }else {
            rbChildTwo.setChecked(true);
        }
    }

    /**
     * save all data at person page now
     */
    private void saveData() {
        String name = etName.getText().toString().trim();
        String birthday = etBirthday.getText().toString().trim();
        String sex = rgSex.getCheckedRadioButtonId() == R.id.rb_sex_one ? "Male" : "Female";
        String blood = "";
        if (rgBlood.getCheckedRadioButtonId() == R.id.rb_blood_one) {
            blood = "A";
        } else if (rgBlood.getCheckedRadioButtonId() == R.id.rb_blood_two) {
            blood = "B";
        } else if (rgBlood.getCheckedRadioButtonId() == R.id.rb_blood_three) {
            blood = "AB";
        } else if (rgBlood.getCheckedRadioButtonId() == R.id.rb_blood_four) {
            blood = "O";
        }
        String nation = etNationality.getText().toString().trim();
        String aller = etAllergies.getText().toString().trim();
        String history = etFam.getText().toString().trim();
        String smoke = etSmoke.getText().toString().trim();
        String alcohol = rgAlcohol.getCheckedRadioButtonId() == R.id.rb_alcohol_one ? "YES" : "NO";
        String mcStr = rgMc.getCheckedRadioButtonId() == R.id.rb_mc_one ? "SINGLE" : "MARRIED";
        String child = rgChild.getCheckedRadioButtonId() == R.id.rb_child_one ? "YES" : "NO";
        Person person = new Person();
        if(personId != 0){
            person.setId(personId);
        }
        person.setName(name);
        person.setBirth(birthday);
        person.setSex(sex);
        person.setBloType(blood);
        person.setNational(nation);
        person.setAllergies(aller);
        person.setFamiHist(history);
        person.setSmoHist(smoke);
        person.setAlcoh(alcohol);
        person.setMarriage(mcStr);
        person.setChild(child);
        dao.insertOrReplace(person);
        ToastUtils.showShort("Save successfully");
        finish();
    }

}
