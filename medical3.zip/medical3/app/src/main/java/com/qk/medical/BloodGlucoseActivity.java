package com.qk.medical;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.blankj.utilcode.util.ToastUtils;
import com.qk.medical.database.operation.MySQLiteOpenHelper;
import com.qk.medical.database.tableInfor.BloodGlucose;
import com.qk.medical.gen.BloodGlucoseDao;
import com.zhy.adapter.recyclerview.CommonAdapter;
import com.zhy.adapter.recyclerview.base.ViewHolder;

import java.util.List;

import butterknife.BindView;
import com.qk.medical.toDB.*;

/**
 * @ClassName: BloodGlucoseActivity
 * @Description: Blood Glucose page
 * @Author:
 * @Version: 1.6.0
 */
public class BloodGlucoseActivity extends BaseActivity {
    @BindView(R.id.btn_add)
    Button btnAdd;
    @BindView(R.id.rv_daily)
    RecyclerView rvBody;
    private BloodGlucoseDao dao;
    private List<BloodGlucose> datas;
    private BloodGlucoseAdapter adapter;
    addToDB add= new addToDB();
    deleteToDB delete= new deleteToDB();

    @Override
    protected int getLayoutId() {
        return R.layout.activity_record;
    }

    @Override
    protected void initToolbar(Bundle savedInstanceState) {
        setTitle("Blood Glucose Record");
    }

    @Override
    protected void initData() {
        //get and show the data in db
        //set db and show record List, and record list can update by transaction
        btnAdd.setOnClickListener(v -> startActivityForResult(new Intent(mContext, BloodGlucoseAddActivity.class), 101));
        rvBody.setLayoutManager(new LinearLayoutManager(mContext));
        dao = MySQLiteOpenHelper.getDaoSession(mContext).getBloodGlucoseDao();
        datas = dao.queryBuilder().orderDesc(BloodGlucoseDao.Properties.Id).build().list();
        adapter = new BloodGlucoseAdapter(mContext, R.layout.item_body_temp, datas);
        rvBody.setAdapter(adapter);
    }

    /**
     * The submodule returns some data to the main Activity for processing
     * @param requestCode confirm the data is returned from which activity
     * @param resultCode RESULT OK > call back
     *                   RESULT CANCELLED > no call back
     * @param data data that passes
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 101 && resultCode == RESULT_OK && data != null){
            String temp = data.getStringExtra("temp");
            String time = data.getStringExtra("time");
            String note = data.getStringExtra("note");
            Long resultId = data.getLongExtra("id", 0L);
            BloodGlucose bloodGlucose = new BloodGlucose();
            bloodGlucose.setBloodGlu(temp);
            bloodGlucose.setDate(time);
            bloodGlucose.setNotes(note);
            bloodGlucose.setId(resultId);
            add.transactionToDB(datas,bloodGlucose);
            adapter.notifyDataSetChanged();
        }
    }

    /**
     * update the cluscose list
     */
    class BloodGlucoseAdapter extends CommonAdapter<BloodGlucose> {

        public BloodGlucoseAdapter(Context context, int layoutId, List<BloodGlucose> datas) {
            super(context, layoutId, datas);
        }

        /**
         *Implement a sliding list
         * @param holder sliding list
         * @param BloodGlucose table's value
         * @param position
         */
        @Override
        protected void convert(ViewHolder holder, BloodGlucose BloodGlucose, int position) {
            holder.setText(R.id.tv_text_one, "time: " + BloodGlucose.getDate());
            holder.setText(R.id.tv_text_two, "GLU: " + BloodGlucose.getBloodGlu() + " mmol/L");
            holder.setText(R.id.tv_text_three, "note: " + BloodGlucose.getNotes());
            holder.setOnClickListener(R.id.iv_item_delete, new View.OnClickListener() {
                /**
                 * when click delete, update the list
                 * @param v
                 */
                @Override
                public void onClick(View v) {
                    delete.transactionToDB(datas,BloodGlucose);
                    delete.delete(dao,BloodGlucose);
                    ToastUtils.showShort("delete successfully");
                    adapter.notifyDataSetChanged();
                }
            });
        }
    }
}
