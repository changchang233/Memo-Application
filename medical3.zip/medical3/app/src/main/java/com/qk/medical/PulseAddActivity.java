package com.qk.medical;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;

import com.blankj.utilcode.util.TimeUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.qk.medical.database.operation.MySQLiteOpenHelper;
import com.qk.medical.database.tableInfor.Breathe;
import com.qk.medical.database.tableInfor.Pulse;
import com.qk.medical.gen.BreatheDao;
import com.qk.medical.gen.PulseDao;
import com.qk.medical.util.QKTextUtils;

import butterknife.BindView;

/**
 * @ClassName: ReminderActivity
 * @Description: 脉冲页面
 * @Author: majia
 * @Version: 1.6.0
 */
public class PulseAddActivity extends BaseActivity {

    @BindView(R.id.et_pulse)
    EditText etPulse;
    @BindView(R.id.et_pulse_note)
    EditText etPulseNote;
    @BindView(R.id.date_picker)
    DatePicker datePicker;
    String time;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_add_pulse;
    }

    @Override
    protected void initToolbar(Bundle savedInstanceState) {
        setTitle("Pulse Add Page");
        showRight(true);
        setRightText("Save");
        setOnRightClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //save
                String tem = etPulse.getText().toString().trim();
                String note = etPulseNote.getText().toString().trim();
                if(QKTextUtils.isNullOrEmpty(tem)){
                    ToastUtils.showShort("please input Pulse");
                    return;
                }
                PulseDao dao = MySQLiteOpenHelper.getDaoSession(mContext).getPulseDao();
                Pulse pulse = new Pulse();
                pulse.setPulse(tem);
                pulse.setDate(time);
                pulse.setNotes(note);
                Long resultId = dao.insert(pulse);
                Log.e("KK", "Add ID=" + resultId);
                Intent resultIntent = new Intent();
                resultIntent.putExtra("temp", tem);
                resultIntent.putExtra("time", time);
                resultIntent.putExtra("note", note);
                resultIntent.putExtra("id", resultId);
                setResult(RESULT_OK, resultIntent);
                finish();
            }
        });
    }

    /**
     * show the calender to show the date
     * user can select date
     */
    @Override
    protected void initData() {
        time = TimeUtils.date2String(TimeUtils.getNowDate(), "yyyy/MM/dd");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            datePicker.setOnDateChangedListener(new DatePicker.OnDateChangedListener() {

                @Override
                public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                    Log.e("KK", "year=" + year + ",month=" + monthOfYear + ",day=" + dayOfMonth);
                    time = new StringBuffer().append(year).append("Year")
                            .append((monthOfYear + 1)).append("Month")
                            .append(dayOfMonth).append("Day").toString();
                }
            });
        }
    }

}
