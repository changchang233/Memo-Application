package com.qk.medical;

import android.app.Application;

import com.qk.medical.database.operation.MySQLiteOpenHelper;

/**
 * @ClassName: App
 * @Description:  create BD
 * @Author:
 * @Version: 1.6.0
 */
public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        initDB();
    }

    private void initDB(){
        MySQLiteOpenHelper.getDaoMaster(this);
    }
}
