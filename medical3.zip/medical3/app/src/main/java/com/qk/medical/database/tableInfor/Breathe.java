/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.qk.medical.database.tableInfor;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;

import java.util.Date;
import org.greenrobot.greendao.annotation.Generated;

/**
 *
 * @author xuxiaoyue
 */
@Entity
public class Breathe {
    @Id
    private Long id;
    private String breathe;
    private String date;
    private String notes;
    @Generated(hash = 731058505)
    public Breathe(Long id, String breathe, String date, String notes) {
        this.id = id;
        this.breathe = breathe;
        this.date = date;
        this.notes = notes;
    }
    @Generated(hash = 89107181)
    public Breathe() {
    }
    public Long getId() {
        return this.id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getBreathe() {
        return this.breathe;
    }
    public void setBreathe(String breathe) {
        this.breathe = breathe;
    }
    public String getDate() {
        return this.date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public String getNotes() {
        return this.notes;
    }
    public void setNotes(String notes) {
        this.notes = notes;
    }

}
